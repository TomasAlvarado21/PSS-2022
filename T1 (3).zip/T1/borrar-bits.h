typedef unsigned int uint;
uint borrar_bits(uint x, uint pat, int len);
