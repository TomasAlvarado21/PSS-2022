void sort(char *nums[], int n);
